package com.vaibhav.mobws;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MobileAppWsApplicationTests {

	@Test
	void contextLoads() {
	}

}
